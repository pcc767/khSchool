package com.beach.api;

import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.beach.model.vo.Beach;

public class beachAPI {

    public static final String KEY = "orCD5outbUakEqSxWPAu4C3NHBeT2DtV5DHSQbUBCr4Wx74vx2MumvtD23yU8ImOKwK8KWIjpiG5ubsei4j9dA%3D%3D";
//    public static final String KEY = "GFYaIRR7h%2B5VzBC0UOr0Dfa1JlCCgM%2Fe6P4cE7yER1%2Bi%2FOSIf8sUDicnuExyGImszns9Bo%2FqfcQR1eXlSiu6jA%3D%3D";
    public static final String BEACH_KEYWORD_LIST_URL = "http://api.visitkorea.or.kr/openapi/service/rest/KorService/searchKeyword";
    public static final String BEACH_DETAIL_LIST_URL = "http://api.visitkorea.or.kr/openapi/service/rest/KorService/detailCommon";

//    http://api.visitkorea.or.kr/openapi/service/rest/KorService/searchKeyword?ServiceKey=orCD5outbUakEqSxWPAu4C3NHBeT2DtV5DHSQbUBCr4Wx74vx2MumvtD23yU8ImOKwK8KWIjpiG5ubsei4j9dA%3D%3D&MobileApp=AppTest&MobileOS=ETC&numOfRows=500&cat1=A01&cat2=A0101&cat3=A01011200&keyword=

//    http://api.visitkorea.or.kr/openapi/service/rest/KorService/detailCommon?ServiceKey=orCD5outbUakEqSxWPAu4C3NHBeT2DtV5DHSQbUBCr4Wx74vx2MumvtD23yU8ImOKwK8KWIjpiG5ubsei4j9dA%3D%3D&MobileApp=AppTest&MobileOS=ETC&contentId=126102
//    http://api.visitkorea.or.kr/openapi/service/rest/KorService/detailCommon?serviceKey=orCD5outbUakEqSxWPAu4C3NHBeT2DtV5DHSQbUBCr4Wx74vx2MumvtD23yU8ImOKwK8KWIjpiG5ubsei4j9dA%3D%3D
//    &numOfRows=10
//    &pageNo=1
//    &MobileOS=ETC
//    &MobileApp=AppTest
//    &contentId=126102

//    &defaultYN=Y
//    &firstImageYN=Y
//    &areacodeYN=Y
//    &catcodeYN=Y
//    &addrinfoYN=Y
//    &mapinfoYN=Y
//    &overviewYN=Y

//    http://api.visitkorea.or.kr/openapi/service/rest/KorService/detailCommon?ServiceKey=orCD5outbUakEqSxWPAu4C3NHBeT2DtV5DHSQbUBCr4Wx74vx2MumvtD23yU8ImOKwK8KWIjpiG5ubsei4j9dA%3D%3D
//    &MobileApp=AppTest
//    &MobileOS=ETC
//    &contentId=2796918

//    &defaultYN=Y
//    &firstImageYN=Y
//    &areacodeYN=Y
//    &catcodeYN=Y
//    &addrinfoYN=Y
//    &overviewYN=


    public static List<Beach> callBeachKeywordByXML(){

        List<Beach> list = new ArrayList<>();
        List<Beach> bList = new ArrayList<>();
        String place = "해수욕장";
        String url_01 = null;
        try {
        	url_01 = URLEncoder.encode(place, "UTF-8");
		} catch (Exception e) {
			e.printStackTrace();
		}
        
        StringBuffer urlBuffer = new StringBuffer();
        urlBuffer.append(BEACH_KEYWORD_LIST_URL);
        urlBuffer.append("?" + "ServiceKey="+KEY);
        urlBuffer.append("&" + "MobileApp=AppTest");
        urlBuffer.append("&" + "MobileOS=ETC");
        urlBuffer.append("&" + "numOfRows=500");
        urlBuffer.append("&" + "cat1=A01");
        urlBuffer.append("&" + "cat2=A0101");
        urlBuffer.append("&" + "cat3=A01011200");
        urlBuffer.append("&" + "keyword="+url_01);

        System.out.println(urlBuffer);
        
        
        try {
            URL url = new URL(urlBuffer.toString());
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/xml");
            int code = conn.getResponseCode();
            System.out.println("Response code: " + code);

            if(code < 200 || code > 300){
                System.out.println("페이지가 잘 못되었습니다.");
                return null;
            }

            //페이지 해석
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            Document doc = db.parse(conn.getInputStream());
            doc.normalizeDocument();

            System.out.println("Root Element : " + doc.getDocumentElement().getNodeName());
            System.out.println("========================================================");

            //태그 선택이 안되는것 같음.--------------------------------------------------------
            NodeList beachList = doc.getElementsByTagName("item");
            System.out.println("파실할 리스트 수 : "+ beachList.getLength());


            for(int i=0; i<beachList.getLength();i++){
                Node node = beachList.item(i);
                System.out.println("\nCurrent Element : " + node.getNodeName());
                if(node.getNodeType() == Node.ELEMENT_NODE){
                    Element eElement = (Element) node;

                    String addr1 = getTagValue(eElement, "addr1");
//                    String addr2 = getStrData(eElement, "addr2");
                    int areacode = getIntData(eElement, "areacode");
                    String contentid = getTagValue(eElement, "contentid");
                    String contenttypeid = getTagValue(eElement, "contenttypeid");

                    Double mapx = getDoubleData(eElement, "mapx");
                    Double mapy = getDoubleData(eElement, "mapy");
                    int mlevel = getIntData(eElement, "mlevel");
                    String title = getStrData(eElement, "title");

                    System.out.println("번호 : "+ (i+1));
                    System.out.println(getStrData(eElement, "title"));
                    System.out.println(getStrData(eElement, "addr1"));
                    System.out.println(getStrData(eElement, "addr2"));
//                    System.out.println(getIntData(eElement, "areacode"));
                    System.out.println(getStrData(eElement, "contentid"));
                    System.out.println(getStrData(eElement, "contenttypeid"));


                    Beach beach = new Beach(title, addr1, areacode, contentid, contenttypeid, mapx, mapy, mlevel);
                    list.add(beach);

                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        
//        BEACH_KEYWORD_LIST_URL--------------------------------------------------------------------------------------------------
        
        String place1 = "해변";
        String url_02 = null;
        try {
            url_02 = URLEncoder.encode(place1, "UTF-8");
		} catch (Exception e) {
			e.printStackTrace();
		}
        
        StringBuffer urlBuffer1 = new StringBuffer();
        urlBuffer1.append(BEACH_KEYWORD_LIST_URL);
        urlBuffer1.append("?" + "ServiceKey="+KEY);
        urlBuffer1.append("&" + "MobileApp=AppTest");
        urlBuffer1.append("&" + "MobileOS=ETC");
        urlBuffer1.append("&" + "numOfRows=500");
        urlBuffer1.append("&" + "cat1=A01");
        urlBuffer1.append("&" + "cat2=A0101");
        urlBuffer1.append("&" + "cat3=A01011200");
        urlBuffer1.append("&" + "keyword="+url_02);

        System.out.println(urlBuffer1);
        
        try {
            URL url = new URL(urlBuffer1.toString());
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/xml");
            int code = conn.getResponseCode();
            System.out.println("Response code: " + code);

            if(code < 200 || code > 300){
                System.out.println("페이지가 잘 못되었습니다.");
                return null;
            }

            //페이지 해석
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            Document doc = db.parse(conn.getInputStream());
            doc.normalizeDocument();

            System.out.println("Root Element : " + doc.getDocumentElement().getNodeName());
            System.out.println("========================================================");

            //태그 선택이 안되는것 같음.--------------------------------------------------------
            NodeList beachList = doc.getElementsByTagName("item");
            System.out.println("파실할 리스트 수 : "+ beachList.getLength());

            for(int i=0; i<beachList.getLength();i++){
                Node node = beachList.item(i);
                System.out.println("\nCurrent Element : " + node.getNodeName());
                if(node.getNodeType() == Node.ELEMENT_NODE){
                    Element eElement = (Element) node;

                    String addr1 = getStrData(eElement, "addr1");
//                    String addr2 = getStrData(eElement, "addr2");
                    int areacode = getIntData(eElement, "areacode");
                    String contentid = getStrData(eElement, "contentid");
                    String contenttypeid = getStrData(eElement, "contenttypeid");

                    Double mapx = getDoubleData(eElement, "mapx");
                    Double mapy = getDoubleData(eElement, "mapy");
                    int mlevel = getIntData(eElement, "mlevel");
                    String title = getStrData(eElement, "title");

                    System.out.println("번호 : "+ (i+1));
                    System.out.println(getStrData(eElement, "title"));
                    System.out.println(getStrData(eElement, "addr1"));
//                    System.out.println(getStrData(eElement, "addr2"));
                    System.out.println(getIntData(eElement, "areacode"));
                    System.out.println(getStrData(eElement, "contentid"));
                    System.out.println(getStrData(eElement, "contenttypeid"));


                    Beach beach = new Beach(title, addr1, areacode, contentid, contenttypeid, mapx, mapy, mlevel);


                    list.add(beach);
                    System.out.println(list.size());
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        
//      =======================================================================================================================
//      BEACH_DETAIL_LIST_URL--------------------------------------------------------------------------------------------------
//      =======================================================================================================================

		for (int j = 0; j < list.size(); j++) {
			StringBuffer urlBuffer2 = new StringBuffer();
			urlBuffer2.append(BEACH_DETAIL_LIST_URL);
			urlBuffer2.append("?" + "ServiceKey=" + KEY);
			urlBuffer2.append("&" + "MobileApp=AppTest");
			urlBuffer2.append("&" + "MobileOS=ETC");
			urlBuffer2.append("&" + "contentId=" + list.get(j).getContentid());
            urlBuffer2.append("&" + "defaultYN=Y");
            urlBuffer2.append("&" + "firstImageYN=Y");
            urlBuffer2.append("&" + "areacodeYN=Y");
            urlBuffer2.append("&" + "catcodeYN=Y");
            urlBuffer2.append("&" + "addrinfoYN=Y");
            urlBuffer2.append("&" + "mapinfoYN=Y");
            urlBuffer2.append("&" + "overviewYN=Y");

			System.out.println(urlBuffer2);

			try {
				URL url = new URL(urlBuffer2.toString());
				HttpURLConnection conn = (HttpURLConnection) url.openConnection();
				conn.setRequestMethod("GET");
				conn.setRequestProperty("Accept", "application/xml");
				int code = conn.getResponseCode();
				System.out.println("Response code: " + code);

				if (code < 200 || code > 300) {
					System.out.println("페이지가 잘 못되었습니다.");
					return null;
				}

				// 페이지 해석
				DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
				DocumentBuilder db = dbf.newDocumentBuilder();
				Document doc = db.parse(conn.getInputStream());
				doc.normalizeDocument();

				System.out.println("Root Element : " + doc.getDocumentElement().getNodeName());
				System.out.println("========================================================");

				NodeList beachList = doc.getElementsByTagName("item");
				System.out.println("파싱할 리스트 수 : " + beachList.getLength());

				for (int i = 0; i < beachList.getLength(); i++) {
					Node node = beachList.item(i);
					System.out.println("\nCurrent Element : " + node.getNodeName());
					if (node.getNodeType() == Node.ELEMENT_NODE) {
						Element eElement = (Element) node;

						System.out.println(getStrData(eElement, "title"));
						System.out.println(getStrData(eElement, "homepage"));
						System.out.println(getStrData(eElement, "firstimage"));
						System.out.println(getStrData(eElement, "overview"));
						System.out.println(getStrData(eElement, "addr1"));

                        String addr1 = getStrData(eElement, "addr1");
                        int areacode = getIntData(eElement, "areacode");
                        int booktour = getIntData(eElement, "booktour");
                        String cat1 = getStrData(eElement, "cat1");
                        String cat2 = getStrData(eElement, "cat2");
                        String cat3 = getStrData(eElement, "cat3");
                        String contentid = getStrData(eElement, "contentid");
                        String contenttypeid = getStrData(eElement, "contenttypeid");
                        String firstimage = getStrData(eElement, "firstimage");
                        String firstimage2 = getStrData(eElement, "firstimage2");
                        String homepage = getStrData(eElement, "homepage");
                        Double mapx = getDoubleData(eElement, "mapx");
                        Double mapy = getDoubleData(eElement, "mapy");
                        int mlevel = getIntData(eElement, "mlevel");
                        String modifiedtime = getStrData(eElement, "modifiedtime");
                        String overview = getStrData(eElement, "overview");
                        int sigungucode = getIntData(eElement, "sigungucode");
                        String title = getStrData(eElement, "title");
                        String zipcode = getStrData(eElement, "zipcode");

						Beach beach = new Beach(contentid, contenttypeid, booktour, homepage, modifiedtime, firstimage,
                                firstimage2, areacode, sigungucode,	cat1, cat2, cat3, addr1, zipcode, mapx, mapy,
                                mlevel, overview, title);

						bList.add(beach);

					}
				}	// 안쪽 for문 close

			} catch (Exception e) {
				e.printStackTrace();
			}
		} // for문 close
//      --------------------------------------------------------------------------------------------------

        Set<Beach> set = new HashSet<>(bList);		// 중복제거
        bList = new ArrayList<>(set);
        
        return bList;
        
    }
    
    
    
    
//  --------------------------------------------------------------------------------------------------



    private static String getTagValue(Element eElement, String tag) {
        Node nValue=null;

        NodeList nodeList = eElement.getElementsByTagName(tag);
        Node node = nodeList.item(0);
        NodeList nList = null;

        if(node != null) {
            nList = node.getChildNodes();
            if((Node)nList.item(0)!=null) {
                nValue = (Node)nList.item(0);
            }
        }
        if(nValue==null)
            return null;

        return nValue.getNodeValue();
    }


    private static String getStrData(Element eElement, String tagName){
        try {
            return eElement.getElementsByTagName(tagName).item(0).getTextContent();
        } catch (Exception e) {
        	e.printStackTrace();
            return "-";
        }
    }
    
    private static int getIntData(Element eElement, String tagName){
		try {
			return Integer.parseInt(eElement.getElementsByTagName(tagName).item(0).getTextContent());
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
	}
	
	private static long getLogData(Element eElement, String tagName){
		try {
			return Long.parseLong(eElement.getElementsByTagName(tagName).item(0).getTextContent());
		} catch (Exception e) {
			return 0;
		}
	}
	
	private static double getDoubleData(Element eElement, String tagName){
		try {
			return Double.parseDouble(eElement.getElementsByTagName(tagName).item(0).getTextContent());
		} catch (Exception e) {
			return 0.0;
		}
	}
	
//  --------------------------------------------------------------------------------------------------



    public static void main(String[] args) {
        callBeachKeywordByXML();

    }

}


//
//System.out.println(getStrData(eElement, "contentid"));
//System.out.println(getStrData(eElement, "contenttypeid"));
//System.out.println(getStrData(eElement, "overview"));
//System.out.println(getStrData(eElement, "addr1"));
//System.out.println(getStrData(eElement, "title"));
//System.out.println(getStrData(eElement, "homepage"));
//System.out.println(getStrData(eElement, "firstimage"));
//System.out.println(getStrData(eElement, "firstimage2"));


