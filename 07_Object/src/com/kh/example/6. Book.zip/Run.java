package com.kh.example.practice6.run;

import com.kh.example.practice6.model.vo.Book;

public class Run {
    public static void main(String[] args) {

        Book bk = new Book();

        bk.inform();


    }

}
