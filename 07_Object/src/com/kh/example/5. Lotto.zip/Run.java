package com.kh.example.practice5.run;

import com.kh.example.practice5.model.vo.Lotto;

public class Run {
	
	 public static void main(String[] args) {

	        Lotto ltt = new Lotto();

	        ltt.information();
	    }

}
