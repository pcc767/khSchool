package com.kh.example.practice4.run;

import com.kh.example.practice4.model.vo.Student;

public class Run {
	public static void main(String[] args) {
		
		Student sd = new Student();

        sd.information();

    }

}
