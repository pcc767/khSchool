package com.kh.homework;

import java.util.Scanner;

public class CastingPractice_03 {
	
	public static void main(String[] args) {
		
		int iNum1 = 10;
		int iNum2 = 4;
		
		float fNum = 3.0f;
		double dNum = 2.5;
		
		char ch = 'A'; //41
		
		System.out.println(iNum1%iNum2);		
		System.out.println((int)dNum);
		System.out.println("--------------------");
		System.out.println((double)(ch/iNum1)+iNum2);
		System.out.println((double)iNum1);
		System.out.println("--------------------");
		System.out.println((double)iNum1/iNum2);
		System.out.println(dNum);  //hahahahah~
		System.out.println("--------------------");
		System.out.println(iNum1/fNum);
		System.out.println((double)iNum1/fNum);
		System.out.println("--------------------");
		System.out.println(ch);
		System.out.println((int)ch);
		System.out.println(ch+iNum1);
		System.out.println((char)(ch+iNum1));
		
	}

}
