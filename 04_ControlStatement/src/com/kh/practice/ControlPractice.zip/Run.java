package com.kh.practice.chap01;

public class Run {
	public static void main(String[] args) {
		ControlPractice cp = new ControlPractice();
//		cp.practice1();
//		cp.practice2();
//		cp.practice3();
		
//		cp.practice4();
//		cp.practice5();
//		cp.practice6();
//		cp.practice7();
//		cp.practice8();
//		cp.practice9();
//		cp.practice10();
		cp.practice11();
	}
	
	
	

}

