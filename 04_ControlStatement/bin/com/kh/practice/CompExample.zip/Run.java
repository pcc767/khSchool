package com.kh.practice.comp.run;

import com.kh.practice.comp.func.CompExample;

public class Run {
	public static void main(String[] args) {
		CompExample ce = new CompExample();
				
//		ce.practice1();
//		ce.practice2();
//		ce.practice3();
//		ce.practice4();
//		ce.practice5();
		ce.practice6();
	}
	
}
