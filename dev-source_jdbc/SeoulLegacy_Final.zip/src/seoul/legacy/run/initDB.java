package seoul.legacy.run;

public class initDB {

}
