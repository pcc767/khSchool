package seoul.legacy.run;

import seoul.legacy.view.LegacyInSeoulView;

public class Run {
	public static void main(String[] args) {
		LegacyInSeoulView lisv = new LegacyInSeoulView();

		lisv.mainMenu();
	}	
}
