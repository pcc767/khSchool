package run;

import member.view.MemberMenu;

public class Run {
	public static void main(String[] args) {
		new MemberMenu().mainMenu();
		System.out.println("---- 프로그램 종료 ----");
	}
}

