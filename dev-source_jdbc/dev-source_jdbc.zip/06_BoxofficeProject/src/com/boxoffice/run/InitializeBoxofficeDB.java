package com.boxoffice.run;

public class InitializeBoxofficeDB {
	public static void main(String[] args) {
		
	}
}
