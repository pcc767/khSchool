package com.boxoffice.run;

import com.boxoffice.view.BoxofficeMenu;

public class Run {

	public static void main(String[] args) {
		new BoxofficeMenu().mainMenu();
		System.out.println("---- 프로그램 종료 ----");
	}

}
