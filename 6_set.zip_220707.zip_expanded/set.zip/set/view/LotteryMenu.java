package com.kh.practice.set.view;

import com.kh.practice.set.controller.LotteryController;
import com.kh.practice.set.model.vo.Lottery;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeSet;

public class LotteryMenu {
    LotteryController lc = new LotteryController();
    public static Scanner sc = new Scanner(System.in);

    public void mainMenu(){
        while (true) {
            System.out.println("========== KH 추첨 프로그램 ==========");
            System.out.println("******* 메인 메뉴 *******");
            System.out.println("1. 추첨 대상 추가");
            System.out.println("2. 추첨 대상 삭제");
            System.out.println("3. 추첨 대상자 확인");
            System.out.println("4. 당첨 대상 확인");
            System.out.println("5. 정렬된 당첨 대상 확인");
            System.out.println("6. 당첨 대상 검색");
            System.out.println("9. 종료");
            System.out.print("메뉴 번호 선택 : ");
            int inputNum = Integer.parseInt(sc.nextLine());

            switch (inputNum) {
                case 1:
                    insertObject();
                    break;
                case 2:
                    deleteObject();
                    break;
                case 3 :
                    printAll();
                    break;
                case 4:
                    winObject();
                    break;
                case 5:
                    sortedWinObject();
                    break;
                case 6:
                    searchWinner();
                    break;
                case 9:
                    System.out.println("프로그램 종료 합니다.");
                    return;
                default:
                    System.out.println("잘 못 입력했습니다. 다시 입력해 주세요.");
            }
        }
    }

    private void printAll() {
        lc.printAll();
    }

    private void insertObject() {
        System.out.print("추첨할 대상 수 : ");
        int choNum = Integer.parseInt(sc.nextLine());
        int count = 0;
        while (choNum > 0){
            System.out.print("추첨자 이름 : ");
            String name = sc.nextLine();
            System.out.print("추첨자 핸드폰 번호 : ");
            String phone = sc.nextLine();

            Lottery lotto = new Lottery(name, phone);
            boolean io = lc.insertObject(lotto);
            if (io)
                count++;
            else {
                System.out.println("중복된 대상입니다. 다시 입력하세요.");
                continue;
            }
            choNum--;
        }
        System.out.println(count+"명 추가 완료되었습니다.");
    }

    private void deleteObject() {
        System.out.print("삭제할 이름 : ");
        String name = sc.nextLine();
        System.out.print("삭제할 핸드폰 번호 : ");
        String phone = sc.nextLine();

        boolean lotto = lc.deleteObject(new Lottery(name, phone));
        System.out.println(lotto);
        if(lotto)
            System.out.println("삭제 완료");
        else
            System.out.println("존재하지 않는 대상입니다.");
    }

    private void winObject() {
        HashSet<Lottery> hashSet = lc.winObject();
        for(Lottery lottery : hashSet)
            System.out.println(lottery);
    }

    private void sortedWinObject() {
        TreeSet<Lottery> treeSet = lc.sortedWinObject();
        Iterator<Lottery> iterator = treeSet.iterator();

        while (iterator.hasNext()){
            Lottery lottery = iterator.next();
            System.out.println(lottery);
        }
    }

    private void searchWinner() {
        System.out.print("추첨자 이름 : ");
        String name = sc.nextLine();
        System.out.print("추첨자 핸드폰 번호 : ");
        String phone = sc.nextLine();

        boolean lotto = lc.searchWinner(new Lottery(name, phone));
        if(lotto)
            System.out.println("축하합니다. 당첨 목록에 존재합니다.");
        else
            System.out.println("안타깝지만 당첨 목록에 존재하지 않습니다.");
    }
}
