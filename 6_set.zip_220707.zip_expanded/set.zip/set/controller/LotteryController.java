package com.kh.practice.set.controller;

import com.kh.practice.set.model.vo.Lottery;

import java.util.*;

public class LotteryController {
    private HashSet<Lottery> lottery = new HashSet<>();
    private HashSet<Lottery> win = new HashSet<>();

    public LotteryController() {
        lottery.add(new Lottery("홍길동", "010-1234-5678"));
        lottery.add(new Lottery("최길동", "010-4321-5678"));
        lottery.add(new Lottery("박길동", "010-1234-5678"));
        lottery.add(new Lottery("김길동", "010-1234-5678"));
        lottery.add(new Lottery("유길동", "010-1234-5678"));
        lottery.add(new Lottery("정길동", "010-1234-5678"));
        lottery.add(new Lottery("james", "010-1234-5678"));
        lottery.add(new Lottery("kooKi", "010-4321-5678"));
        lottery.add(new Lottery("김유신", "010-1234-5678"));
        lottery.add(new Lottery("세동", "010-1234-5678"));
        lottery.add(new Lottery("홍진호", "010-1234-5678"));
        lottery.add(new Lottery("우광", "010-1234-5678"));
    }

    public void printAll(){
        for(Lottery lotto : lottery)
            System.out.println(lotto);
    }

    public boolean insertObject(Lottery l){
        return lottery.add(l);
    }

    public boolean deleteObject(Lottery l){
        Boolean lotto = lottery.remove(l);

        if(lotto && !win.isEmpty()){
            win.remove(l);
        }
        return lotto;
    }

    public HashSet<Lottery> winObject(){
        if(lottery.size() < 4)
            return null;
        ArrayList<Lottery> arrayList = new ArrayList<>(lottery);
        Random random = new Random();
        while (win.size() < 4){
            win.add(arrayList.get(random.nextInt(arrayList.size())));
        }
        return win;
    }

    public TreeSet<Lottery> sortedWinObject(){
        TreeSet<Lottery> treeSet = new TreeSet<>(new Comparator<Lottery>() {
            @Override
            public int compare(Lottery o1, Lottery o2) {
                int result = o1.getName().compareTo(o2.getName());
                if (result == 0)
                    result = o2.getPhone().compareTo(o1.getPhone());
                return result;
            }
        });

        HashSet<Lottery> hashSet = winObject();
        treeSet.addAll(hashSet);
        return treeSet;
    }

    public boolean searchWinner(Lottery l){
        System.out.println(lottery.contains(l));
        return win.contains(l);
    }
}
